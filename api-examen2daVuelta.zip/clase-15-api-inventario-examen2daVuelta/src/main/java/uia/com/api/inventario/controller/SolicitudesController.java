package uia.com.api.inventario.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uia.com.api.inventario.service.SolicitudEntregaService;
import uia.com.api.inventario.service.SolicitudMaterialService;

import java.util.ArrayList;

@RestController
@RequestMapping("/Solicitudes")
@CrossOrigin(origins = "http://localhost:4200")
public class SolicitudesController {

    private SolicitudMaterialService solicitudMaterialService;
    private SolicitudEntregaService solicitudEntregaService;

    @Autowired
    public SolicitudesController(SolicitudMaterialService solicitudMaterialService, SolicitudEntregaService solicitudEntregaService) {
        this.solicitudMaterialService = solicitudMaterialService;
        this.solicitudEntregaService = solicitudEntregaService;
    }

    @GetMapping
    public ResponseEntity<ArrayList<Object>> getAll() {
        ArrayList<Object> response = new ArrayList<Object>();
        response.addAll(solicitudMaterialService.getAll());

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}